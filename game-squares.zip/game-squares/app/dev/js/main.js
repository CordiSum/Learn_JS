/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./app/src/js/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./app/src/js/main.js":
/*!****************************!*\
  !*** ./app/src/js/main.js ***!
  \****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var webp_in_css_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webp-in-css/polyfill */ "./node_modules/webp-in-css/polyfill.js");
/* harmony import */ var webp_in_css_polyfill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(webp_in_css_polyfill__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _squares__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./squares */ "./app/src/js/squares.js");


document.addEventListener('DOMContentLoaded', function () {
  var start = document.querySelector('.start');
  var newGame = document.querySelector('.new-game');
  var points = document.querySelector('.points');
  var timerWrap = document.querySelector('.timer-wrap');
  var tableTop = document.querySelector('.table-top'); // start timer

  start.addEventListener('click', function () {
    countdown();
  }); // timer

  var timer;
  var playTime = 3; // let seconds = Math.floor((playTime / 1000) % 60);
  // let minutes = Math.floor((playTime / 1000 / 60) % 60);

  function countdown() {
    timerWrap.innerHTML = playTime;
    playTime--;

    if (playTime < 0) {
      clearTimeout(timer);
      console.log('0');
    } else {
      timer = setTimeout(countdown, 1000);
    }
  }
});

/***/ }),

/***/ "./app/src/js/squares.js":
/*!*******************************!*\
  !*** ./app/src/js/squares.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var field = document.querySelector('.playing-field');
var square;
var randomColor; //индекс массива color 

var arrayColor = ['transparent', 'red', 'green', 'blue'];
var arrSquares = [];

function getRandomColor(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min;
}

var ObjSquare = function ObjSquare(id, color, point) {
  _classCallCheck(this, ObjSquare);

  this.id = id;
  this.color = color;
  this.point = point;
};

;

var Filed = /*#__PURE__*/function () {
  function Filed() {
    _classCallCheck(this, Filed);
  }

  _createClass(Filed, [{
    key: "render",
    value: function render() {
      for (var i = 1; i <= 100; i++) {
        randomColor = getRandomColor(0, arrayColor.length);
        square = new ObjSquare(i + 1, arrayColor[randomColor], randomColor);
        field.insertAdjacentHTML('afterbegin', "<div id=\"".concat(square.id, "\" class=\"square ").concat(square.color, "\" value=\"").concat(square.point, "\"></div>"));
        console.log(randomColor);
      }
    }
  }]);

  return Filed;
}();

var filed = new Filed();
var renderObjSquare = filed.render(); // суммирование баллов

field.addEventListener("click", function (event) {
  // навешиваем один обработчик на родительский элемент
  var squares = document.querySelectorAll('.square');
  console.log(squares.indexOf(event.target)); // в свойстве `target` будет содержаться непосредственно тот элемент, по которому кликнули
});
/* harmony default export */ __webpack_exports__["default"] = (renderObjSquare);

/***/ }),

/***/ "./node_modules/webp-in-css/polyfill.js":
/*!**********************************************!*\
  !*** ./node_modules/webp-in-css/polyfill.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var i=new Image;i.onload=i.onerror=function(){document.body.classList.add(i.height==1?"webp":"no-webp")};i.src="data:image/webp;base64,UklGRhoAAABXRUJQVlA4TA0AAAAvAAAAEAcQERGIiP4HAA==";


/***/ })

/******/ });
//# sourceMappingURL=main.js.map